# Cards do Guri — loja virtual

Projeto inicial em Next.js 15, TypeScript, Supabase e Mercado Pago, preparado para deploy na Vercel.

## Instalação local

1. Instale Node.js 20 ou superior.
2. Rode `npm install` e `npm run dev`.
3. Abra `http://localhost:3000`.
4. Sem variáveis de ambiente, a vitrine funciona com produtos demonstrativos. **Não há checkout funcional sem serviços configurados.**

## Supabase

1. Crie projeto Supabase e execute `supabase/schema.sql` no SQL Editor.
2. Copie `.env.example` para `.env.local` e preencha URL, anon key e service role key.
3. Em Authentication > Users, crie seu usuário administrador.
4. No SQL Editor, execute `insert into public.admin_users(user_id) values ('UUID_DO_USUARIO');`.
5. Entre em `/admin` com e-mail e senha. As políticas RLS impedem que usuários comuns alterem produtos.

## Mercado Pago

1. Crie uma aplicação no Mercado Pago Developers e configure credenciais de teste inicialmente.
2. Preencha `MERCADO_PAGO_ACCESS_TOKEN`, `MERCADO_PAGO_WEBHOOK_SECRET` e `NEXT_PUBLIC_SITE_URL` com a URL HTTPS pública da loja.
3. Configure notificações Webhooks para `https://SEU-DOMINIO/api/webhook`, evento `payment`.
4. O servidor cria preferências de Checkout Pro; o Mercado Pago oferece os meios habilitados na sua conta, incluindo Pix/cartão quando disponíveis.
5. Teste pagamentos aprovados, pendentes, recusados, duplicados e concorrentes antes de produção.

## Vercel

Suba a pasta para um repositório GitHub e importe em vercel.com/new. Configure as variáveis de ambiente no projeto Vercel, faça deploy e atualize `NEXT_PUBLIC_SITE_URL` para o domínio definitivo. Não publique `.env.local`.

## Limitações importantes antes de vender

- O catálogo inicial é demonstrativo e não contém fotos reais nem cadastro completo de variantes.
- A função de confirmação de pagamento debita estoque atomicamente e evita processar duas vezes o mesmo pedido, **mas não reserva estoque antes do pagamento**. Em vendas concorrentes (especialmente spots únicos), é necessário implementar reserva com expiração e tratamento de pagamento aprovado sem estoque, antes de operar comercialmente.
- A página administrativa inicial cadastra produtos e ajusta estoque; edição completa, upload de fotos, relatórios de pedidos, envio/frete e gestão de clientes são próximas etapas.
- Não há cálculo de frete, captura de endereço, política de devolução, termos de uso ou LGPD implementados.
- O retorno do comprador para a página do carrinho não comprova pagamento. A confirmação depende exclusivamente do webhook verificado.
- A assinatura do webhook deve ser validada em ambiente de testes do Mercado Pago antes de habilitar produção.
- Implemente conciliação periódica de pagamentos e reprocessamento de notificações com erro.
