import {demoProducts,type Product} from './data';
import {publicDb} from './supabase';
export async function catalog():Promise<Product[]>{const db=publicDb();if(!db)return demoProducts;const {data,error}=await db.from('products').select('id,slug,name,category,price,stock,emoji,description').eq('active',true).order('created_at',{ascending:false});if(error)throw new Error('Falha ao carregar catálogo');return (data||[]) as Product[]}
