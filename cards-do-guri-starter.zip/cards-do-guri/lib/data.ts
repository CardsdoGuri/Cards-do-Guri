export type Product = {id:string;slug:string;name:string;category:'cards'|'boxes'|'breaks'|'accessories';price:number;stock:number;emoji:string;description:string};
export const demoProducts:Product[]=[
{id:'card-1',slug:'card-neymar',name:'Card Neymar Jr. — Edição Especial',category:'cards',price:45,stock:3,emoji:'⚽',description:'Card colecionável demonstrativo. Substitua pela foto e descrição reais.'},
{id:'box-1',slug:'box-futebol',name:'Hobby Box — Futebol',category:'boxes',price:750,stock:2,emoji:'📦',description:'Box lacrada demonstrativa.'},
{id:'break-1',slug:'break-champions',name:'Break Box Champions — Spot 01',category:'breaks',price:180,stock:1,emoji:'🏆',description:'Spot demonstrativo de break. Cada spot deve ter seu próprio SKU e estoque.'},
{id:'acc-1',slug:'toploaders',name:'Toploaders — Pacote com 25',category:'accessories',price:35,stock:10,emoji:'🛡️',description:'Acessório demonstrativo para proteção de cards.'},
];
export const brl=(n:number)=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
