-- Execute no SQL Editor do Supabase. Nunca exponha a service_role key ao navegador.
create extension if not exists pgcrypto;
create table if not exists public.products (id uuid primary key default gen_random_uuid(),slug text unique not null,name text not null,category text not null check(category in ('cards','boxes','breaks','accessories')),price numeric(12,2) not null check(price>0),stock integer not null default 0 check(stock>=0),emoji text not null default '🃏',description text not null default '',active boolean not null default true,created_at timestamptz not null default now());
create table if not exists public.orders (id uuid primary key default gen_random_uuid(),status text not null default 'pending',total numeric(12,2) not null,mercadopago_payment_id text unique,created_at timestamptz not null default now());
create table if not exists public.order_items (id uuid primary key default gen_random_uuid(),order_id uuid not null references public.orders(id),product_id uuid not null references public.products(id),quantity integer not null check(quantity>0),unit_price numeric(12,2) not null);
create table if not exists public.admin_users (user_id uuid primary key references auth.users(id));
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.admin_users enable row level security;
create policy "Produtos públicos" on public.products for select to anon,authenticated using (active or exists(select 1 from public.admin_users where user_id=(select auth.uid())));
create policy "Admin insere produtos" on public.products for insert to authenticated with check(exists(select 1 from public.admin_users where user_id=(select auth.uid())));
create policy "Admin altera produtos" on public.products for update to authenticated using(exists(select 1 from public.admin_users where user_id=(select auth.uid()))) with check(exists(select 1 from public.admin_users where user_id=(select auth.uid())));
create policy "Admin consulta pedidos" on public.orders for select to authenticated using(exists(select 1 from public.admin_users where user_id=(select auth.uid())));
create policy "Admin consulta itens" on public.order_items for select to authenticated using(exists(select 1 from public.admin_users where user_id=(select auth.uid())));
-- Esta função só pode ser chamada pelo servidor com service_role.
create or replace function public.confirm_paid_order(p_order_id uuid,p_payment_id text,p_amount numeric) returns void language plpgsql security definer set search_path=public as $$
declare o public.orders%rowtype; i record;
begin
 select * into o from public.orders where id=p_order_id for update;
 if not found then raise exception 'Pedido não encontrado'; end if;
 if o.status='paid' then return; end if;
 if o.status<>'pending' or o.total<>p_amount then raise exception 'Pedido/valor incompatível'; end if;
 for i in select * from public.order_items where order_id=p_order_id order by product_id loop
   update public.products set stock=stock-i.quantity where id=i.product_id and stock>=i.quantity;
   if not found then raise exception 'Estoque insuficiente para pedido %',p_order_id; end if;
 end loop;
 update public.orders set status='paid',mercadopago_payment_id=p_payment_id where id=p_order_id;
end $$;
revoke all on function public.confirm_paid_order(uuid,text,numeric) from public,anon,authenticated;
grant execute on function public.confirm_paid_order(uuid,text,numeric) to service_role;
